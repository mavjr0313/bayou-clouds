//
//  AppDelegate.swift
//  watchOSsample
//
//  Created by Boris Bügling on 13/06/15.
//  Copyright © 2015 Boris Bügling. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey : Any]? = nil) -> Bool {
        return true
    }

}

