//
//  AppDelegate.swift
//  Vendored Framework Example
//
//  Created by Mark Spanbroek on 15/04/16.
//  Copyright © 2016 CocoaPods. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

}
