//
//  AppDelegate.h
//  MultiXcodeProject
//
//  Created by Sebastian Edward Shanus on 11/7/18.
//  Copyright © 2018 CocoaPods. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

