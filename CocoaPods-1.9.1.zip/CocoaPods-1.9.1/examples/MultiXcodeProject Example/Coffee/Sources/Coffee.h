

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Coffee : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) CGFloat density;

@end

NS_ASSUME_NONNULL_END
