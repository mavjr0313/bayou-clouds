@interface ABC (Private)
+ (void)barkSuperLoudly;
@end