#import <ObjCPod/abc.h>
#import "abc_private.h"

#import <Foundation/Foundation.h>

@implementation ABC
+ (void)bark { NSLog(@"woof woof"); }
+ (void)barkSuperLoudly { NSLog(@"WOOF WOOF"); }
@end
