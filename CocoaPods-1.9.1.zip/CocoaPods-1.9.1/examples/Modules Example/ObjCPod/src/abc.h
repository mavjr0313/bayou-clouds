@interface ABC : NSObject
+ (void)bark;
@end