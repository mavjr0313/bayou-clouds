@import Foundation;

@interface BCE : NSObject
+ (void)meow;
@end
