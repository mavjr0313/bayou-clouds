public struct Empty {}
