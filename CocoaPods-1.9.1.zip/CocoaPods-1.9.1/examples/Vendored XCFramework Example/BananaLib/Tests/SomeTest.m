
@import XCTest;
#import "SomeTest.h"
#import <CoconutLib/CoconutLib.h>

@implementation SomeTest: XCTestCase 

- (void) testSomething {
	CoconutObj *coconut = [CoconutObj new];
}

@end
