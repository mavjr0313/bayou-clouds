
#import <Foundation/Foundation.h>

/** Minions are awesome */
@interface MinionsObj : NSObject
@end
