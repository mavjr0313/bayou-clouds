//
//  main.swift
//  SampleCommandLineTool
//
//  Created by Eric Amorde on 5/5/19.
//  Copyright © 2019 CocoaPods. All rights reserved.
//

import Foundation

print("Hello, World!")

